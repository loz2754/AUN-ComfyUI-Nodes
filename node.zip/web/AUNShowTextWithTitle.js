import { app } from "/scripts/app.js";
import { api } from "/scripts/api.js";
import { ComfyWidgets } from "../../../scripts/widgets.js";

// This extension adds a node that displays text with a title

app.registerExtension({
  name: "AUNNodes.ShowTextWithTitle",

  async setup() {
    // Listen for the custom message from the Python backend to set the title
    api.addEventListener("AUN.set_node_title", ({ detail }) => {
      if (!detail.node_id || !app.graph) {
        return;
      }

      // Find the node on the canvas by its ID
      const node = app.graph.getNodeById(detail.node_id);
      if (node) {
        // Set the title and mark the canvas as dirty to trigger a redraw
        node.title = detail.title || `AUN Show Text With Title`;
        app.graph.setDirtyCanvas(true, true);
      }
    });
  },
  // This function is called before a node is registered with the graph
  async beforeRegisterNodeDef(nodeType, nodeData, app) {
    if (nodeData.name === "AUNShowTextWithTitle") {
      function populate(text) {
        if (this.widgets) {
          // On older frontend versions there is a hidden converted-widget
          const isConvertedWidget = +!!this.inputs?.[0].widget;
          for (let i = isConvertedWidget; i < this.widgets.length; i++) {
            this.widgets[i].onRemove?.();
          }
          this.widgets.length = isConvertedWidget;
        }

        const v = [...text];
        if (!v[0]) {
          v.shift();
        }
        for (let list of v) {
          // Force list to be an array, not sure why sometimes it is/isn't
          if (!(list instanceof Array)) list = [list];
          for (const l of list) {
            const w = ComfyWidgets["STRING"](
              this,
              "text_" + this.widgets?.length ?? 0,
              ["STRING", { multiline: true }],
              app,
            ).widget;
            if (w.inputEl) {
              w.inputEl.readOnly = true;
              w.inputEl.style.opacity = 0.6;
            }
            w.value = l;
          }
        }

        requestAnimationFrame(() => {
          const sz = this.computeSize();
          if (sz[0] < this.size[0]) {
            sz[0] = this.size[0];
          }
          if (sz[1] < this.size[1]) {
            sz[1] = this.size[1];
          }
          this.onResize?.(sz);
          app.graph.setDirtyCanvas(true, false);
        });
      }

      // When the node is executed we will be sent the input text, display this in the widget
      const onExecuted = nodeType.prototype.onExecuted;
      nodeType.prototype.onExecuted = function (message) {
        onExecuted?.apply(this, arguments);
        populate.call(this, message.text);
      };

      const VALUES = Symbol();
      const configure = nodeType.prototype.configure;
      nodeType.prototype.configure = function () {
        // Store unmodified widget values as they get removed on configure by new frontend
        this[VALUES] = arguments[0]?.widgets_values;
        return configure?.apply(this, arguments);
      };

      const onConfigure = nodeType.prototype.onConfigure;
      nodeType.prototype.onConfigure = function () {
        onConfigure?.apply(this, arguments);
        const widgets_values = this[VALUES];
        if (widgets_values?.length) {
          // In newer frontend there seems to be a delay in creating the initial widget
          requestAnimationFrame(() => {
            populate.call(
              this,
              widgets_values.slice(
                +(widgets_values.length > 1 && this.inputs?.[0].widget),
              ),
            );
          });
        }
      };
    }
  },
});
